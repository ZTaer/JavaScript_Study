// 第一题: 求阿里数
function test(num){
    // 计算
    const arrNum = (num.toString()).split("");
    let sum = 0;
    for( let cur of arrNum ){
        sum = sum + (+cur)**2;
    }

    // 根据不同的条件决定是否递归
        // 返回true: 为阿里数
        // 返回false: 为非阿里数
    if( sum === 1 ){
        return true;
    }
    else if ( sum !== 1 && sum.toString().length === 1 ){
        return false;
    }
    else {
        return test( sum );
    }
}

for( let i = 0; i <= 100; i++ ){
    if(test(i)){
        console.log(i);
    }
}