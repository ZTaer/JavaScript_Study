let vm = Vue.createApp({
  data() {
    return {
      mode: 1
    }
  }
}).mount('#app');
