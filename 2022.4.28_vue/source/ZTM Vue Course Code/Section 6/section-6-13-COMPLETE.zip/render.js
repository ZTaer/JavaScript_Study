function render(_ctx, _cache, $props, $setup, $data, $options) {
  return Object(
    null,
    null,
    [
      Object("img", { "alt": "Vue logo", "src": "./assets/logo.png" }),
      Object("h1", null, "Hello"),
      Object(HelloWorld, {
        msg: "Welcome to Your Vue.js App"
      })
    ]
  )
}