let vm = Vue.createApp({
  data() {
    return {
      message: "Hello world!"
    }
  }
}).mount('#app')