import pizza from './pizza'

pizza.pepperoni()
pizza.bacon()
