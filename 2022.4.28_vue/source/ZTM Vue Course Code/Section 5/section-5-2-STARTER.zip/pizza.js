export default {
  pepperoni: function() {
    console.log('Pepperoni topping added!')
  },
  bacon: function() {
    console.log('Bacon topping added!')
  }
}
