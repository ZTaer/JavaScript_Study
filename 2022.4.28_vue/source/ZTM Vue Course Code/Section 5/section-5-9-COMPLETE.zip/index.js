import pizza from './pizza'
import './main.scss'

pizza.pepperoni()
pizza.bacon()
