export default {
  state: {
    foo: 'bar',
  },
};
