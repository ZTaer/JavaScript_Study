const app = Vue.createApp({
  data: () => ({
    title: 'Hello',
  }),
}).mount('#app')