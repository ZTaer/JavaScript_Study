
 let bv;
 
 oo7.backgroundVideo(bv,'#container','#background_video',['https://xyq.res.netease.com/pc/gw/20170118103441/data/render-mp4.mp4','222.mp4'],'#video_cover',0);

/*
  bv.init({
    // 0. 抓取HTML视频标签
    videoEl: document.querySelector('#background_video'),

    // 1. 抓取容器 - 视频父类标签
    container: document.querySelector('#container'),

    // 自动调整视频大小，达到background-size:cover;效果
    resize: true,

    // 检测到移动端停止播放视频
    isMobile: window.matchMedia('(max-width: 768px)').matches,

    // 2. 获取视频路径,并限制格式
    src: [
      {
        src: '222.mp4',
        type: 'video/mp4'
      },
      {
        src: 'night.webm',
        type: 'video/webm;codecs="vp8, vorbis"'
      }
    ],

    // 3. 设置视频缓冲图片背景图  
    onLoad: function () {
      document.querySelector('#video_cover').style.display = 'none';
    }
  });
*/